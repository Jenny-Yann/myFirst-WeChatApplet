Page({
  /**
  * 页面的初始数据
  */
  data: {
    inputValue: '', //搜索的内容
    part_list: [
      {
        id: 1,
        sub: "第一条订单",
        price:"100元",
        stopTime:"2222-22-22",
        details:"详情内容xxxxxxxxxxxxxxx",
        contact:"123456789"
      },
      {
        id: 2,
        sub:"项目名称2",
        price:"200元",
        stopTime: "2222-33-33",
        details: "详情内容yyyyyyyyyy",
        contact: "123456789"
      }
    ]
  },

  //搜索框文本内容显示
  inputBind: function (event) {
    this.setData({
      inputValue: event.detail.value
    })
    console.log('bindInput' + this.data.inputValue)

  },
  /**
  * 搜索执行按钮
  */
  query: function (event) {

  },

  gotoDetails:function(e){
      wx.setStorageSync("order",e.currentTarget.dataset.order)
      wx.navigateTo({
        url: '/pages/details/details'
      })
  },
  gotoBook:function(){

  }
})
