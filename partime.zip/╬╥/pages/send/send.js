// pages/send/send.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    services:["二手交易","校园兼职","帮你跑腿"],
    index:0,
    date:"2018-5-21",
    saveToastHidden: true,
  /* 提交给服务器的数据*/
    serve:"",
    sub:"",
    details:"",
    contact:"",
    price:"",
    stopTime:""

  },
  bindService:function(e){
    this.setData({
      index:e.detail.value,
      serve: this.data.services[e.detail.value]
    })
  },
  bindDate:function(e){
    this.setData({
      date:e.detail.value,
      stopTime:e.detail.value
    })
  },
  bindTitle:function(e){
    this.setData({
      sub:e.detail.value
    })
  },
  bindDetails:function(e){
    this.setData({
      details:e.detail.value
    })
  },
  bindContact:function(e){
    this.setData({
      contact:e.detail.value
    })
  },
  bindPrice:function(e){
    this.setData({
      price:e.detail.value
    })
  },
  submitForm: function (e) {
    var order={
      serve: this.data.serve,
      sub: this.data.sub,
      details: this.data.details,
      contact: this.data.contact,
      price: this.data.price,
      stopTime: this.data.stopTime
    }
    wx.setStorageSync("order", order)
    console.log('保存成功')
    this.setData({
      saveToastHidden: false
    })
  },
  hideToast:function(e){
    this.setData({
      saveToastHidden: true
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      serve:this.data.services[this.data.index],
      stopTime:this.data.date
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})